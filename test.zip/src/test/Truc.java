package test;

public class Truc {



		    public static void main(String[] args) {
		        System.out.println("Left Padding: " + leftPad("abcd", 8));
		        System.out.println("Right Padding: " + rightPad("abcd", 8));
		        
		        String [] tabCSV = {"Muszynski", "Anne-Claire", "O"};
		        String [] tabCSV2 = {"Bob", "Jean", "O"};
		        
		        System.out.println("Left Padding: ");
		        System.out.print(leftPad(tabCSV, 20));
		        System.out.println(leftPad(tabCSV2, 20));
		        System.out.println("Right Padding: ");
		        System.out.print(rightPad(tabCSV, 20));
		        System.out.print(rightPad(tabCSV2, 20));
		        
		    }

		    public static String leftPad(String s, int width) {
		    	String [] tab = {s};
		        return String.format("%" + width + "s", tab);
		    }

		    public static String rightPad(String s, int width) {
		    	String [] tab = {s};
		        return String.format("%-" + width + "s", tab);
		        
		    }
		    public static String leftPad(String [] s, int width) {
		    	return String.format("%" + width + "s", s);
		    }

		    public static String rightPad(String [] s, int width) {
		        return String.format("%-" + width + "s", s);
		        
		    }
		}

