package test;

public class Tel {



	public static void main(String[] args) {

		String p_Adresse = "2   RUE POISSON";
		System.out.println("v1 : " + p_Adresse);
		String adresse = p_Adresse.replaceAll("[ ]{2,}", " ");
		System.out.println("v2 : " + adresse);


	}
}
