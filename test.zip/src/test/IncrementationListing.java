package test;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.RandomAccessFile;

public class IncrementationListing {

	public static void ecrire(File p_File) throws Exception
	{
		FileWriter writer =
	            new FileWriter(p_File, true);
		writer.write("1");
		writer.write("\r\n");
		writer.write("ligne 1");
		writer.write("\r\n");
		writer.write("ligne 2");
		writer.write("\r\n");
		writer.close();

	}
	
	public static boolean readReplace(String fileName, String oldPattern,
            String replPattern, int lineNumber) {
        String line;
        StringBuffer sb = new StringBuffer();
        int nbLinesRead = 0;
        try {
            FileInputStream fis = new FileInputStream(fileName);
            BufferedReader reader = new BufferedReader(new InputStreamReader(
                    fis));
            while ((line = reader.readLine()) != null) {
                nbLinesRead++;
                line = line.toLowerCase();
 
                if (nbLinesRead == lineNumber) {
                    line = line.replaceFirst(oldPattern.toLowerCase(),
                            replPattern);
                }
                sb.append(line + "\r\n");
            }
            reader.close();
            BufferedWriter out = new BufferedWriter(new FileWriter(fileName));
            out.write(sb.toString());
            out.close();
 
        } catch (Exception e) {
            return false;
        }
        return true;
    }
	
	public static void recuperer(String p_File) throws Exception
	{
		System.out.println("debut recup");
		RandomAccessFile raf = new RandomAccessFile(p_File, "r");
		String ligne = raf.readLine();
		ligne = raf.readLine();
		String num = ligne.substring(0, ligne.indexOf(' '));
		int ligneInt = Integer.parseInt(num);
		System.out.println("num ligne : " + ligneInt);
		raf.close();
		readReplace(p_File, String.valueOf(ligneInt), String.valueOf(ligneInt + 1), 2);

		System.out.println("fin recup");
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("debut");
		String fileName = "F:\\tmp\\test.txt";
		File file = new File(fileName);
		try {
			ecrire(file);
			recuperer(fileName);
			System.out.println("fin");

		} catch (Exception e) {
			System.out.println("erreur : " + e);
		}

	}

}
