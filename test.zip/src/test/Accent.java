package test;

public class Accent {

	public static void main(String[] args) {

		String[] tab = { "pr�no�8_", "nom$" };
		String nomDossier = tab[0] + "-" + tab[1];
		System.out.println(nomDossier);
		nomDossier = nomDossier.toUpperCase();
		System.out.println(nomDossier);
		nomDossier = nomDossier.replaceAll("[����]", "E");
		nomDossier = nomDossier.replaceAll("[���]", "A");
		nomDossier = nomDossier.replaceAll("[��]", "I");
		nomDossier = nomDossier.replaceAll("[��]", "O");
		nomDossier = nomDossier.replaceAll("[���]", "U");
		nomDossier = nomDossier.replaceAll("[�]", "AE");
		nomDossier = nomDossier.replaceAll("[�]", "OE");
		System.out.println(nomDossier);
		nomDossier= nomDossier.replaceAll("[^\\w-]|_","");
		
		System.out.println("der : " + nomDossier);
	}

}