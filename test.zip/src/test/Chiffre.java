package test;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import com.csvreader.CsvWriter;

public class Chiffre {
   public static final String[] ENTETE_CSV = { "Nom", "Pr�nom", "DateNaiss", "Tel", "Mobile",
		      "Mail", "Photo", "Adr1", "Adr2", "Adr3", "CP", "Ville", "Commentaire" };


	public static void main(String[] args) {

		try {

			System.out.println("Debut");
			Calendar cal = Calendar.getInstance();
			String format = "dd-MM-yyyy";
			SimpleDateFormat formater = new SimpleDateFormat(format);
			cal.add(Calendar.DAY_OF_YEAR, 4);

			String date = formater.format(cal.getTime());

			System.out.println("date : " + date);

			String nom = "ROMANI-JEROME-E-4-DFEKT1E";

			String base = "F:\\test\\truc";
			String fichier = "texte13.csv";

			String chemin = base + File.separator + date + File.separator + nom
					+ File.separator;

			System.out.println("chemin : " + chemin);
			File repertoire = new File(chemin);
			if(false == repertoire.exists())
			{
				System.out.println("Le r�pertoire " + repertoire + " n'existe pas");
				repertoire.mkdirs();
				System.out.println(repertoire + " cr��");

			}
			String filePath = repertoire + File.separator + fichier;
			File file = new File(filePath);
			if(false == file.exists())
			{
				System.out.println(file.getName() + " n'existe pas");
				file.createNewFile();
				System.out.println(file.getName() + " cr��");
				CsvWriter writer = new CsvWriter(new FileWriter(filePath), '\t');
				writer.writeRecord(ENTETE_CSV);
				writer.close();

			}
		
			System.out.println("Debut �criture");
			
			CsvWriter writer = new CsvWriter(new FileWriter(filePath, true), '\t');

			//Create record
		      String [] record = "5\tDavid\tMiller\tAustralia\t30".split("\t");
		      //Write the record to file
		      writer.writeRecord(record);
		        
		      //close the writer
		      writer.close();
//	        FileWriter fileWriter = new FileWriter(filePath, true);
//			BufferedWriter bufWriter = new BufferedWriter(fileWriter);
//			bufWriter.newLine();
//            bufWriter.write("");
//            bufWriter.close();

	        System.out.println("Fin �criture");
			
		} catch (Exception e) {
			System.out.println("erreur");
			e.printStackTrace();
		}

		System.out.println("Fin");

	}
}
