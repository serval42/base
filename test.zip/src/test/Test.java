package test;



public class Test {

	public static String change(String p_St) {
		String res = p_St.substring(0, p_St.lastIndexOf("."));
		res = res.replace("\"", "_");
		res = res.replace(" ", "_");
		res = res.replace("|", "_");
		res = res.replace("\\", "_");
		res = res.replace("/", "_");
		res = res.replace("*", "_");
		res = res.replace(".", "_");
		res = res.replace("?", "_");
		res = res.replace(":", "_");
		res = res.replace("<", "_");
		res = res.replace(">", "_");
		return res;
	}

	public static String change2(String p_NomFichier) {
		String res = "";
	      // on r�cup�re l'extension
	      String extension = "";
	      if (p_NomFichier.lastIndexOf(".") > 0)
	      {
	         extension = p_NomFichier.substring(p_NomFichier.lastIndexOf("."), p_NomFichier.length());
	         res = p_NomFichier.substring(0, p_NomFichier.lastIndexOf(extension));
	      }
	      else
	      {
	         res = p_NomFichier;
	      }
	      res = res.replaceAll("[ \"|/*?:<\\\\>]", "_");
	      // le '\' passe pas dans le remplaceAll
//	      res = res.replace("\\", "_");
	      if((extension != "") && (extension.length() > 1 ))
	      {
	         res = res.concat(extension);
	      }
	      return res;

	}
	
	
	
	   protected static String getPrenomCorrect(String p_Prenom)
	   {
	      String result = "";
	      StringBuffer sb = new StringBuffer(p_Prenom.toLowerCase());
	      sb = sb.replace(0, 1, sb.substring(0, 1).toUpperCase());
	      //s'il y a un tiret dans le pr�nom
	      int tiret = sb.indexOf("-");
	      if(-1 != tiret)
	      {
	    	  sb = sb.replace(tiret+1, tiret + 2, sb.substring(tiret+1, tiret+2).toUpperCase());
	      }
	      
	      result = sb.toString();
	      return result;
	   }
	   
	   protected static String getNomCorrect(String p_Nom)
	   {
	      String retour = p_Nom;
	      retour = retour.toUpperCase();
	      retour = retour.replaceAll("[����]", "E");
	      retour = retour.replaceAll("[����]", "A");
	      retour = retour.replaceAll("[��]", "I");
	      retour = retour.replaceAll("[��]", "O");
	      retour = retour.replaceAll("[��]", "U");
	      retour = retour.replaceAll("[�]", "C");
	      retour = retour.replaceAll("[�]", "AE");
	      retour = retour.replaceAll("[�]", "OE");
	      retour = retour.replaceAll("[^\\w-]|_", "");
	      return retour;
	   }

	public static void main(String[] args) {

		String p_NomFichier = "JEAN-MICJE";
		String p_NomFichier2 = "jean�ou-jean";
		System.out.println("change 1 : " + getPrenomCorrect(p_NomFichier));
		System.out.println("change 2 : " + getNomCorrect(p_NomFichier2));
		System.out.println("fin ");

	}
}