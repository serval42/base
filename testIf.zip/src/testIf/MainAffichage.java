package testIf;

import java.util.Calendar;

public class MainAffichage {

	public static void main(String[] args) {

		Calendar cal = Calendar.getInstance();
		cal.set(2016, 02, 06, 12, 00, 00);
		System.out.println(cal.getTimeInMillis());

	}
}
