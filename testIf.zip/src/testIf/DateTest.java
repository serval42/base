package testIf;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import org.apache.commons.lang3.StringUtils;


public class DateTest {
	
	final static String FORMAT_DATE = "dd/MM/yyyy";
	final static SimpleDateFormat FORMATER = new SimpleDateFormat(FORMAT_DATE);

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("DEBUT");

		Calendar calJour = Calendar.getInstance();
		calJour.set(Calendar.DAY_OF_MONTH, 1);
		calJour.set(Calendar.MONTH, 8);
		calJour.set(Calendar.YEAR, 2015);
		
		String debut = "01/09";
		String incr = "1";
		
		System.out.println("caljour : " + FORMATER.format(calJour.getTime()));
		System.out.println("get : " + getAnneeReference(calJour.getTime(), debut, incr));
		
		System.out.println("FIN");
		
	}

	public static String getAnneeReference(Date p_Date,
			String p_ParamDateReferenceDebut,
			String p_ParamDateReferenceIncrement) {
		// date du jour
		Calendar calDateDuJour = Calendar.getInstance();

		// date pass�e en param
		Calendar calDateReference = Calendar.getInstance();
		calDateReference.setTime(p_Date);
		int anneeDocument = (calDateReference.get(Calendar.YEAR));

		String res = anneeDocument + "";

		// extraction des donn�es
		String jour = StringUtils.left(p_ParamDateReferenceDebut,
				p_ParamDateReferenceDebut.indexOf("/"));
		String mois = StringUtils.right(p_ParamDateReferenceDebut,
				p_ParamDateReferenceDebut.indexOf("/"));

		// calcul de la date en fcto de la date du jour et de l'ann�e du doc
		calDateDuJour.set(Calendar.DAY_OF_MONTH, Integer.valueOf(jour));
		calDateDuJour.set(Calendar.MONTH, Integer.valueOf(mois) - 1);
		calDateDuJour.set(Calendar.YEAR, anneeDocument);

		if (calDateReference.before(calDateDuJour)) {
			System.out.println("moins 1");
			res = (anneeDocument - Integer
					.valueOf(p_ParamDateReferenceIncrement)) + "";
		} else {
			System.out.println("pas de changement");
		}

		return res;
	}

}
