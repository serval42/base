package testIf;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.util.Random;

public class SQLTransformer {

	public static void main(String[] args) {
		// Penser � changer le nom du fichier source
		String nomFichier = "F:/test/export_mesures2_v2.0.csv";
		String fichierMS = "F:/test/donnees.sql";
		BufferedReader lecteurAvecBuffer = null;
		BufferedWriter bufferEcrireMS = null;
		String ligne;

		try {
			lecteurAvecBuffer = new BufferedReader(new FileReader(nomFichier));
			bufferEcrireMS = new BufferedWriter(new OutputStreamWriter(
					new FileOutputStream(fichierMS), "UTF-8"));
			lecteurAvecBuffer.readLine();

			while ((ligne = lecteurAvecBuffer.readLine()) != null) {
				String[] tab = ligne.split(";");

				bufferEcrireMS
						.write("INSERT INTO entite_metier (type, date_insertion, donnees, localisation_point)");
				bufferEcrireMS.write("VALUES ('MESURE_COMPENSATOIRE',");
				bufferEcrireMS.write("'2016-11-01 00:00:00',");
				bufferEcrireMS.write("'{");
				bufferEcrireMS.write("\"nom\":\"" + tab[1] + "\",");
				bufferEcrireMS.write("\"dateParution\":\"" + "15-12-2016" + "\",");
				if (tab.length > 8) {
					bufferEcrireMS.write("\"descriptionCourte\":\"" + tab[8]
							+ "\",");
				}
				bufferEcrireMS.write("\"thematique\":\"" + tab[4] + "\"");
				bufferEcrireMS.write("}':: JSONB,");

				bufferEcrireMS.write("ST_AsText('");
				bufferEcrireMS.write(tab[3] + "')::geography);");

				bufferEcrireMS.newLine();

			}
			lecteurAvecBuffer.close();

			bufferEcrireMS.close();
			System.out.println("fini");

		} catch (FileNotFoundException exc) {
			System.out.println("Erreur d'ouverture");

		} catch (IOException ioe) {
			System.out.println("Erreur de fermeture");
		}

	}

}
