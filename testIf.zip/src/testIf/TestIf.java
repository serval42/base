package testIf;

public class TestIf {
	private Integer un;
	private Integer deux;
	private Integer trois;
	public Integer getUn() {
		return un;
	}
	public void setUn(Integer un) {
		this.un = un;
	}
	public Integer getDeux() {
		return deux;
	}
	public void setDeux(Integer deux) {
		this.deux = deux;
	}
	public Integer getTrois() {
		return trois;
	}
	public void setTrois(Integer trois) {
		this.trois = trois;
	}
	public static void main(String[] args) {
	
		String bob = "<br/>cou&nbsp;cou";
		System.out.println("bob : " + bob);
		bob = bob.replaceAll("[&nbsp;]|[<br/>]", "");
		System.out.println("bob : " + bob);
	}
}
