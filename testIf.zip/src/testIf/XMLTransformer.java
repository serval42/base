package testIf;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.OutputStreamWriter;

public class XMLTransformer {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//Penser � changer le nom du fichier source
		String nomFichier = "F:/test/new.txt";
		String fichierXML = "F:/test/test2.xml";
		BufferedReader lecteurAvecBuffer = null;
		BufferedWriter bufferEcrire = null;
		String balisePrincipale ="listeQuartiers";
		String baliseSecondaire ="quartier";
		String ligne;

		try {
			lecteurAvecBuffer = new BufferedReader(new FileReader(nomFichier));
			bufferEcrire = new BufferedWriter(new OutputStreamWriter(
					new FileOutputStream(fichierXML), "UTF-8"));

			bufferEcrire.write("<" + balisePrincipale + ">");
			// on saute la premi�re ligne (l'ent�te)
//			lecteurAvecBuffer.readLine();
			while ((ligne = lecteurAvecBuffer.readLine()) != null) {
				// System.out.println(ligne);
				bufferEcrire.newLine();
				bufferEcrire.write("   <" + baliseSecondaire + ">");
				bufferEcrire.newLine();
				bufferEcrire.write("      <label>");
				// attention penser � mettre le label voulue
				bufferEcrire.write(ligne);
				bufferEcrire.write("</label>");

				bufferEcrire.newLine();
				bufferEcrire.write("      <value>");
				// attention penser � mettre la valeur voulue
				bufferEcrire.write(ligne);
				bufferEcrire.write("</value>");

				bufferEcrire.newLine();
				bufferEcrire.write("   </" + baliseSecondaire + ">");
			}
			bufferEcrire.newLine();
			bufferEcrire.write("</" + balisePrincipale + ">");
			lecteurAvecBuffer.close();
			bufferEcrire.close();
			System.out.println("fini");

		} catch (FileNotFoundException exc) {
			System.out.println("Erreur d'ouverture");

		} catch (IOException ioe) {
			System.out.println("Erreur d'ouverture");
		}

	}

}
