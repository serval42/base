package testIf;

import java.awt.Graphics;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;

public class TestImage {

	public static void main(String[] args) {

		String diskFilename = "F:\\tmp\\cmt\\apercu-carte-mut-izly.png";

		File fichier = new File(diskFilename);
		String extension = diskFilename.substring(diskFilename.lastIndexOf(".")+1);
		System.out.println(extension);
		System.out.println(diskFilename);
		BufferedImage bfImage;
		try {

			bfImage = ImageIO.read(fichier);
			Image reduite = bfImage.getScaledInstance(185, 127,
					bfImage.getType());

			bfImage = toBufferedImage(reduite);
			ImageIO.write(bfImage, extension, fichier);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	private static BufferedImage toBufferedImage(Image image) {
		/** On test si l'image n'est pas d�ja une instance de BufferedImage */
		if (image instanceof BufferedImage) {
			return ((BufferedImage) image);
		} else {
			/** On s'assure que l'image est compl�tement charg�e */
			image = new ImageIcon(image).getImage();

			/** On cr�e la nouvelle image */
			BufferedImage bufferedImage = new BufferedImage(
					image.getWidth(null), image.getHeight(null),
					BufferedImage.TYPE_INT_RGB);

			Graphics g = bufferedImage.createGraphics();
			g.drawImage(image, 0, 0, null);
			g.dispose();

			return (bufferedImage);
		}
	}

}
