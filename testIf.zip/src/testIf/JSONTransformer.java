package testIf;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.util.Random;

public class JSONTransformer {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// Penser � changer le nom du fichier source
		String nomFichier = "F:/test/new.csv";
		String fichierEI = "F:/test/villesEI2.json";
		String fichierMS = "F:/test/villesMS2.json";
		BufferedReader lecteurAvecBuffer = null;
		BufferedWriter bufferEcrireEI = null;
		BufferedWriter bufferEcrireMS = null;
		String ligne;

		try {
			lecteurAvecBuffer = new BufferedReader(new FileReader(nomFichier));
			bufferEcrireEI = new BufferedWriter(new OutputStreamWriter(
					new FileOutputStream(fichierEI), "UTF-8"));
			bufferEcrireMS = new BufferedWriter(new OutputStreamWriter(
					new FileOutputStream(fichierMS), "UTF-8"));

			bufferEcrireEI.write("[");
			bufferEcrireEI.newLine();

			bufferEcrireMS.write("[");
			bufferEcrireMS.newLine();

			while ((ligne = lecteurAvecBuffer.readLine()) != null) {
				Random rand = new Random();
				int nombre = rand.nextInt(10); // Entre 0 et 3
				String[] tab = ligne.split(",");
				if (nombre == 0) {
					bufferEcrireEI.write("{");
					bufferEcrireEI.write("\"code\":\"" + tab[0] + "\",");
					bufferEcrireEI.write("\"departement\":\"" + tab[1] + "\",");
					bufferEcrireEI.write("\"nom\":\"" + tab[2] + "\",");
					bufferEcrireEI.write("\"lat\":\"" + tab[4] + "\",");
					bufferEcrireEI.write("\"long\":\"" + tab[3] + "\",");
					bufferEcrireEI.write("\"altMin\":\"" + tab[5] + "\",");
					bufferEcrireEI.write("\"altMax\":\"" + tab[6] + "\",");
					bufferEcrireEI.write("\"type\":\"EI\"");
					bufferEcrireEI.write("},");
					bufferEcrireEI.newLine();
				} else if (nombre == 1) {
					bufferEcrireMS.write("{");
					bufferEcrireMS.write("\"code\":\"" + tab[0] + "\",");
					bufferEcrireMS.write("\"departement\":\"" + tab[1] + "\",");
					bufferEcrireMS.write("\"nom\":\"" + tab[2] + "\",");
					bufferEcrireMS.write("\"lat\":\"" + tab[4] + "\",");
					bufferEcrireMS.write("\"long\":\"" + tab[3] + "\",");
					bufferEcrireMS.write("\"altMin\":\"" + tab[5] + "\",");
					bufferEcrireMS.write("\"altMax\":\"" + tab[6] + "\",");

					bufferEcrireMS.write("\"altMax\":\"" + tab[6] + "\",");
					bufferEcrireMS.write("\"type\":\"MS\"");
					bufferEcrireMS.write("},");
					bufferEcrireMS.newLine();
				} else {
					// ne fait rien
				}

			}
			bufferEcrireEI.write("]");
			lecteurAvecBuffer.close();

			bufferEcrireMS.write("]");

			bufferEcrireEI.close();
			bufferEcrireMS.close();
			System.out.println("fini");

		} catch (FileNotFoundException exc) {
			System.out.println("Erreur d\"ouverture");

		} catch (IOException ioe) {
			System.out.println("Erreur d\"ouverture");
		}

	}

}
