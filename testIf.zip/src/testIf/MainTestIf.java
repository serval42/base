package testIf;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.GregorianCalendar;

public class MainTestIf {

	private static GregorianCalendar convertirStringEnGregorianCalendar(
			String p_Date) {
		GregorianCalendar cal = new GregorianCalendar();
		cal.clear();

		String[] tabStrDate = p_Date.split("/");

		// -1 car dans le GregorianCalendar Janvier est � 0
		cal.set(Integer.parseInt(tabStrDate[2]),
				Integer.parseInt(tabStrDate[1]) - 1,
				Integer.parseInt(tabStrDate[0]));
		return (cal);
	}
	
	private static String convertGregorianCalendarString(GregorianCalendar cal) {
		DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
		java.util.Date dateDate = cal.getTime();

		return dateFormat.format(dateDate);
	}

	public static void main(String[] args) {
		
		String p_dateDebut = "30/08/2015";
		String p_dateFin = "31/07/2016";

		GregorianCalendar calDebut = convertirStringEnGregorianCalendar(p_dateDebut);
		GregorianCalendar calFin = convertirStringEnGregorianCalendar(p_dateFin);
		System.out.println("date fin " + convertGregorianCalendarString(calFin));
		
		if (calDebut.get(GregorianCalendar.DAY_OF_WEEK) == GregorianCalendar.SATURDAY
				|| calDebut.get(GregorianCalendar.DAY_OF_WEEK) == GregorianCalendar.SUNDAY) {
			calDebut.add(GregorianCalendar.DAY_OF_YEAR, 7);
		}

		calDebut.set(Calendar.DAY_OF_WEEK, Calendar.MONDAY);

		GregorianCalendar calLundi = new GregorianCalendar();
		GregorianCalendar calVendredi = new GregorianCalendar();

		calFin.set(Calendar.DAY_OF_WEEK, Calendar.MONDAY);
		System.out.println("date fin " + convertGregorianCalendarString(calFin));
		calFin.add(GregorianCalendar.DAY_OF_YEAR, 6);
		System.out.println("date fin " + convertGregorianCalendarString(calFin));
		
		System.out.println("avant test date debut " + convertGregorianCalendarString(calDebut));
		System.out.println("avant test date fin " + convertGregorianCalendarString(calFin));
		
		while (calDebut.before(calFin)) {
			calLundi.setTime(calDebut.getTime());

			// on cherche le vendredi
			calVendredi.setTime(calLundi.getTime());
			calVendredi.add(GregorianCalendar.DAY_OF_YEAR, 4);
			// on cr�e un item dans la liste d�roulante
			System.out.println("du " + convertGregorianCalendarString(calLundi)
					+ " au " + convertGregorianCalendarString(calVendredi));
			// on passe � la semaine suivante
			calDebut.add(GregorianCalendar.DAY_OF_YEAR, 7);
			System.out.println("date debut " + convertGregorianCalendarString(calDebut));
		}
		
		System.out.println("Fin test");
	}

}
