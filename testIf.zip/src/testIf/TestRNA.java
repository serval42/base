package testIf;

public class TestRNA {

	
	   public static String getRnaDecoupee(String p_Rna, String p_Separateur)
	   {
	      StringBuilder sb = new StringBuilder();
	
	         sb.append(p_Rna.substring(0, 3)).append(p_Separateur);
	         sb.append(p_Rna.substring(3, 5)).append(p_Separateur);
	         for(int i = 5; i < 10 ; i ++){
	            sb.append(p_Rna.charAt(i));
	            sb.append(p_Separateur);
	         }

	         // ajoute le num�ro initial
	         sb.append(p_Rna);
	      
	      return sb.toString();
	   }
	   
	   public static void main(String[] args) {
		String rna = "W313021255";
		System.out.println("RNA : " + rna);
		System.out.println("RNA d�coup� : " + getRnaDecoupee(rna, "/"));
		
	   }
}
