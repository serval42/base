package time;

import java.text.SimpleDateFormat;
import java.util.Calendar;

public class Compte {

	final static String DATE_STRING = "06/12/2015 19:00";
	final static String FORMAT_DATE = "dd/MM/yyyy HH:mm";
	final static SimpleDateFormat FORMATER = new SimpleDateFormat(FORMAT_DATE);

	public static String[] dateString(){

		String[] retour = new String[2];
		Calendar cal = Calendar.getInstance();

		cal.set(2015, 11, 06, 19, 00, 00);

//		Date dateCible = cal.getTime();

//		System.out.println("date cible : " + FORMATER.format(dateCible));

		long cibleMillis = cal.getTimeInMillis();
		long dateJourMillis = Calendar.getInstance().getTimeInMillis();
		long diff = cibleMillis - dateJourMillis;

		long diffSec = (diff / 1000) % 60;
		long diffMin = (diff / 60000) % 60;
		long diffH = (diff / 3600000) % 24;

//		Time diffTemps = new Time(diff);

		long nbJour = diff / 86400000;
		long nbSem = nbJour / 7;

//		System.out.println("Temps : " + diffTemps);
//		System.out.println("Temps : " + diffH + ":" + diffMin);

//		System.out.println("test : " + nbJour + " jours \nsoit " + nbSem
//				+ " semaines, " + (nbJour % 7) + " jours " + diffH
//				+ " heure, " + diffMin + " minutes et " + diffSec + " secondes");
//		retour = nbJour + " jours \nsoit " + nbSem
//				+ " semaines, " + (nbJour % 7) + " jours " + diffH
//				+ " heure, " + diffMin + " minutes et " + diffSec + " secondes";
		retour[0] = nbJour + " jours";
		retour[1] = nbSem
				+ " semaines, " + (nbJour % 7) + " jours, " + diffH
				+ " heure, " + diffMin + " minutes et " + diffSec + " secondes";
		return retour;
		

	}

}
