package time;

import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class Fenetre {

	final static ActionListener action = new ActionListener() {
		public void actionPerformed(ActionEvent e) {
			label1.setText(Compte.dateString()[0]);
			label2.setText(Compte.dateString()[1]);
		}
	};

	static JPanel PANEL2;
	static JPanel PANEL;
	static JPanel PANEL3;
	static JLabel label1;
	static JLabel label2;

	public static void main(String[] args) {
		JFrame frame = new JFrame();
		// affectation du titre et de l'ic�ne
		frame.setTitle("Time");
		// affectation de l'op�ration � effectuer lors de la fermeture de la
		// fen�tre
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		// taille et position
		frame.setPreferredSize(new Dimension(450, 150));
		frame.setLocationRelativeTo(null); // la fen�tre est centr�e � l'�cran

		PANEL2 = new JPanel();
		PANEL2.setLayout(new GridBagLayout());

		JButton bouton = new JButton("Mise � jour");
		bouton.addActionListener(action);

		label1 = new JLabel();
		label1.setText(Compte.dateString()[0]);
		label1.setHorizontalAlignment(JLabel.CENTER);

		label2 = new JLabel();
		label2.setText(Compte.dateString()[1]);
		label2.setHorizontalAlignment(JLabel.CENTER);


		GridBagConstraints gbc = new GridBagConstraints();
		gbc.weightx = 1;
		gbc.weighty = 1;

		gbc.gridx = 1;
		gbc.gridwidth = 2;
		gbc.gridheight = 2;
		gbc.gridy = 0;
		PANEL2.add(bouton, gbc);

		gbc.gridx = 1;
		gbc.gridwidth = 1;
		gbc.gridheight = 1;
		gbc.gridy = 2;
		PANEL2.add(label1, gbc);
		
		gbc.gridx = 1;
		gbc.gridwidth = 1;
		gbc.gridheight = 1;
		gbc.gridy = 3;
		PANEL2.add(new JLabel("soit"), gbc);

		gbc.gridx = 1;
		gbc.gridwidth = 1;
		gbc.gridheight = 1;
		gbc.gridy = 4;
		PANEL2.add(label2, gbc);

		frame.add(PANEL2);
		
		// rendre la fen�tre visible, pack fait en sorte que tous les composants
		// de l'application soient �
		// leur preferredSize, ou au dessus
		frame.pack();
		frame.setVisible(true);
	}
}
